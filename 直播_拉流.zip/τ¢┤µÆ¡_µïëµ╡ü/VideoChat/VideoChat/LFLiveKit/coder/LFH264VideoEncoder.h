//
//  LFH264VideoEncoder
//  LFLiveKit
//
//  Created by feng on 7/5/16.
//  Copyright (c) 2014 zhanqi.tv. All rights reserved.
//
#import "LFVideoEncoding.h"

@interface LFH264VideoEncoder : NSObject <LFVideoEncoding> {
 
}

- (void)shutdown;

@end
