# VideoChat
用直播的推流和拉流实现的一对一视频聊天,主要是为了练习和了解推拉流的步骤<br/>
详细介绍请看我的简书[用直播(推拉流)模拟实现视频聊天功能](http://www.jianshu.com/p/1b57c02cf9e0)<br/>
IJKPlayer下载地址[戳这里](https://pan.baidu.com/s/1o7Frs06)<br/>
