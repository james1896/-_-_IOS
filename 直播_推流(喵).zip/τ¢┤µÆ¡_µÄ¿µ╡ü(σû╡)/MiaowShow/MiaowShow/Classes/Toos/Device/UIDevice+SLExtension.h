//
//  UIDevice+SLExtension.h
//  HealthyNews
//
//  Created by ALin on 16/1/3.
//  Copyright © 2016年 ALin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIDevice (SLExtension)
+ (NSString*)deviceVersion;
@end
