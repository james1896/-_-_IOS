//
//  ALinRefreshGifHeader.h
//  MiaowShow
//
//  Created by ALin on 16/6/14.
//  Copyright © 2016年 ALin. All rights reserved.
//

#import <MJRefresh/MJRefresh.h>

@interface ALinRefreshGifHeader : MJRefreshGifHeader

@end
