//
//  XMGTopWindow.h
//  HealthyNews
//
//  Created by ALin on 16/1/22.
//  Copyright © 2016年 ALin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SLTopWindow : NSObject
+ (void)show;
+ (void)hide;
@end
