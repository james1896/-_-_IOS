//
//  ALinUser.m
//  MiaowShow
//
//  Created by ALin on 16/6/14.
//  Copyright © 2016年 ALin. All rights reserved.
//

#import "ALinUser.h"
#import <MJExtension/MJExtension.h>

@implementation ALinUser
+ (NSDictionary *)mj_replacedKeyFromPropertyName
{
    return @{@"newStar":@"new"};
}
@end
