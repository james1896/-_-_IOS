//
//  ALinHotLiveCell.h
//  MiaowShow
//
//  Created by ALin on 16/6/15.
//  Copyright © 2016年 ALin. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ALinLive;
@interface ALinHotLiveCell : UITableViewCell
/** 直播 */
@property (nonatomic, strong) ALinLive *live;
@end
