//
//  ALinGPUBeautifyFilter.h
//  MiaowShow
//
//  Created by ALin on 16/7/4.
//  Copyright © 2016年 ALin. All rights reserved.
//

#import <GPUImage.h>

@interface ALinGPUBeautifyFilter : GPUImageFilterGroup

@end
